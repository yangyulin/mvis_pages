# SPDX-License-Identifier: MIT
# Copyright (c) 2026 Yulin Yang / openmvis.com
"""Read and sanity-check the calibration-motion replay pack. Needs only numpy.

    python3 check_pack.py [PACK_DIR]        (default: the folder this file is in)

For every motions/<id>.csv it checks that the quaternions are unit length, recomputes the gyro from the
quaternions and the specific force from the positions by finite differences, and compares them with the gyro and
accel columns (RMS difference). It also checks that the camera times lie inside the motion and that the segments
cover it. Gravity in the world (board) frame is (0, +9.81, 0) m/s^2.
"""
import sys
from pathlib import Path

import numpy as np

G_W = np.array([0.0, 9.81, 0.0])


def load_csv(path):
    return np.loadtxt(path, delimiter=",", skiprows=1, ndmin=2)


def quat_mul(a, b):
    """Hamilton product of (..., 4) quaternions in w, x, y, z order."""
    aw, ax, ay, az = np.moveaxis(a, -1, 0)
    bw, bx, by, bz = np.moveaxis(b, -1, 0)
    return np.stack([aw * bw - ax * bx - ay * by - az * bz,
                     aw * bx + ax * bw + ay * bz - az * by,
                     aw * by - ax * bz + ay * bw + az * bx,
                     aw * bz + ax * by - ay * bx + az * bw], -1)


def quat_log(q):
    """Rotation vector (rad) of unit quaternions (..., 4), w, x, y, z."""
    q = np.where(q[..., :1] < 0, -q, q)
    v = q[..., 1:]
    s = np.linalg.norm(v, axis=-1)
    ang = 2.0 * np.arctan2(s, q[..., 0])
    k = np.where(s > 1e-12, ang / np.maximum(s, 1e-12), 2.0)
    return v * k[..., None]


def quat_to_R(q):
    w, x, y, z = np.moveaxis(q, -1, 0)
    return np.stack([np.stack([1 - 2 * (y * y + z * z), 2 * (x * y - w * z), 2 * (x * z + w * y)], -1),
                     np.stack([2 * (x * y + w * z), 1 - 2 * (x * x + z * z), 2 * (y * z - w * x)], -1),
                     np.stack([2 * (x * z - w * y), 2 * (y * z + w * x), 1 - 2 * (x * x + y * y)], -1)], -2)


def check_motion(pack, mid):
    d = load_csv(pack / "motions" / f"{mid}.csv")
    t, p, q, gyro, acc = d[:, 0], d[:, 1:4], d[:, 4:8], d[:, 8:11], d[:, 11:14]
    dt = np.diff(t)
    norm_err = np.abs(np.linalg.norm(q, axis=1) - 1.0).max()
    # gyro (IMU frame) at the midpoint of each sample pair: w = Log(q_k^-1 q_k+1) / dt
    qc = q[:-1] * np.array([1, -1, -1, -1])
    w_fd = quat_log(quat_mul(qc, q[1:])) / dt[:, None]
    w_mid = 0.5 * (gyro[:-1] + gyro[1:])
    g_rms = np.sqrt(np.mean(np.sum((w_fd - w_mid) ** 2, axis=1)))
    # specific force f = R_W_I^T (a_W - g_W), a_W by central second difference
    h = 0.5 * (dt[1:] + dt[:-1])
    a_W = ((p[2:] - p[1:-1]) / dt[1:, None] - (p[1:-1] - p[:-2]) / dt[:-1, None]) / h[:, None]
    R = quat_to_R(q[1:-1])
    f_fd = np.einsum("nji,nj->ni", R, a_W - G_W)
    a_rms = np.sqrt(np.mean(np.sum((f_fd - acc[1:-1]) ** 2, axis=1)))
    tc = load_csv(pack / "motions" / f"{mid}_camera_times.csv")[:, 1]
    seg = np.genfromtxt(pack / "motions" / f"{mid}_segments.csv", delimiter=",", skip_header=1,
                        usecols=(0, 1))
    ok_cam = bool(tc.min() >= t[0] and tc.max() <= t[-1] and np.all(np.diff(tc) > 0))
    ok_seg = bool(abs(seg[0, 0] - t[0]) < 1e-3 and abs(seg[-1, 1] - t[-1]) < 1e-2
                  and np.allclose(seg[1:, 0], seg[:-1, 1], atol=1e-3))
    return dict(samples=len(t), duration_s=t[-1] - t[0], rate_hz=1.0 / np.median(dt), quat_norm_max_err=norm_err,
                gyro_rms_diff_rad_s=g_rms, gyro_rms_rad_s=np.sqrt(np.mean(np.sum(gyro ** 2, axis=1))),
                accel_rms_diff_m_s2=a_rms, camera_frames=len(tc), camera_times_ok=ok_cam, segments_ok=ok_seg)


def main():
    pack = Path(sys.argv[1]) if len(sys.argv) > 1 else Path(__file__).resolve().parent
    ids = sorted(p.stem for p in (pack / "motions").glob("*.csv")
                 if not p.stem.endswith(("_segments", "_camera_times")))
    bad = 0
    for mid in ids:
        r = check_motion(pack, mid)
        good = (r["quat_norm_max_err"] < 1e-9 and r["gyro_rms_diff_rad_s"] < 1e-2 * max(r["gyro_rms_rad_s"], 1e-3)
                and r["accel_rms_diff_m_s2"] < 0.05 and r["camera_times_ok"] and r["segments_ok"])
        bad += not good
        print(f"{'ok  ' if good else 'FAIL'} {mid}: " + ", ".join(
            f"{k} {v:.3g}" if isinstance(v, float) else f"{k} {v}" for k, v in r.items()))
    for f in sorted((pack / "rigs").glob("*_board_points.csv")):
        b = load_csv(f)
        print(f"ok   {f.name}: {len(b)} points, all z = 0: {bool(np.all(b[:, 3] == 0))}")
    sys.exit(1 if bad else 0)


if __name__ == "__main__":
    main()
