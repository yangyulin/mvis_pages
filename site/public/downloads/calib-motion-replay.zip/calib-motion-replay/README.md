# Calibration motion: replay pack

Use this pack to rerun the digital-twin checks behind <https://openmvis.com/guides/calibration-motion/>. With it
you can:

- **replay** the four motions in your own simulator;
- **calibrate** them with your own camera–IMU tool;
- **judge** the result with the same pass rule we used.

We ran the twin and the solves with MVIS, our camera–IMU calibration tool. MVIS is not public yet, but nothing in
this pack needs it. The files are plain CSV, YAML and JSON, and every convention is written down below.

## Files

| File | What it is | Licence |
|---|---|---|
| `motions/guide06c_60.csv` | Guide motion, 60 s (synthetic, AprilGrid twin `G3_insight9_aprilgrid`) | CC BY 4.0 |
| `motions/guide09_60.csv` | Chessboard version, 60 s (synthetic, built from the chessboard example; chessboard twin `G3_insight9_chess`) | CC BY 4.0 |
| `motions/aprilgrid_06.csv` | AprilGrid example: trajectory of a real hand-held take, 41 s (AprilGrid twin) | CC BY-NC 4.0 |
| `motions/chessboard_1109_09.csv` | Chessboard example: trajectory of a real hand-held take, 51 s (chessboard twin) | CC BY-NC 4.0 |
| `motions/<id>_segments.csv` | Start, end and name of each move (`t0_s, t1_s, move, label`) | as its motion |
| `motions/<id>_camera_times.csv` | Camera trigger times the twin used (`frame, t_s`) | as its motion |
| `rigs/G3_insight9_aprilgrid.yaml` | AprilGrid twin rig: camera, IMU, T_I_C, truth, noise, gates, solve setup | CC BY 4.0 |
| `rigs/G3_insight9_chess.yaml` | Chessboard twin rig, same keys | CC BY 4.0 |
| `rigs/<rig>_board_points.csv` | Board corner 3D points in the board frame (`id, x_m, y_m, z_m`) | CC BY 4.0 |
| `results/<id>.json` | Our twin result per motion: sigma, errors, reference sigma, ratio and pass flags per parameter | as its motion |
| `results/reference_sigmas.json` | Sigmas of the two 80 s reference motions (the trajectories are not published) | CC BY 4.0 |
| `check_pack.py` | Optional numpy-only reader and consistency check | MIT |

**Licences:**

- **CC BY 4.0:** the synthetic guide motions, their results, the twin rigs and the reference sigmas.
- **CC BY-NC 4.0:** the two real-example trajectories and their results. The trajectories come from our own
  Looper Insight 9 recordings, so they carry the same licence as our other Looper data.

**What the real examples are:**

- Only the camera pose path fitted to each recording. No camera images or recordings are included.
- The real monitor leaned back a little (about 0.1 rad in the chessboard take). The twin keeps every board upright.
  So on the real examples, gravity in the board frame differs from the recording by that tilt.

Licence texts: <https://creativecommons.org/licenses/by/4.0/>, <https://creativecommons.org/licenses/by-nc/4.0/>.
Please cite the page above (openmvis.com, Calibration motion guide).

## Frames and conventions

- **World W = board frame B.**
  - Origin: the centre of tag 0 (AprilGrid) or inner corner 0 (chessboard).
  - Axes: x along the board rows, y down the board, z the board normal pointing toward the camera.
  - Gravity: the board stands upright, so `g_W = (0, +9.81, 0)` m/s^2 (the board's y axis points down).
  - The board pose in the world is the identity.
- **Camera C:** x right, y down, z along the optical axis. **IMU I:** the Insight 9 IMU body frame.
- **Transforms:** `T_A_B` maps points from frame B to frame A: `X_A = R_A_B X_B + p_A_B`.
  - `T_I_C` is camera to IMU (`p_I_C` = camera centre in the IMU frame).
  - The motion files give `T_W_I`.
- **Rotations:** quaternions in **w, x, y, z** order (Hamilton, `R(q)` maps the right frame to the left), or
  log(R) rotation vectors in rad. No Euler angles anywhere.
- **Units:** SI (m, s, rad, m/s^2). Result errors use mrad, mm, ms, ppm and px, as named in each file.
- **Time:** `t = 0` is the start of each motion. All times are on the IMU clock. The camera clock offset `td`
  (the camera–IMU time offset) is given below.

### `motions/<id>.csv` (200 Hz)

`t_s, p_W_I_{x,y,z}_m, q_W_I_{w,x,y,z}, gyro_{x,y,z}_rad_s, accel_{x,y,z}_m_s2`

- `p_W_I`, `q_W_I`: IMU position and orientation in the world (board) frame.
- `gyro`: ideal angular rate of the IMU in the IMU frame (`w_I`, from `R_W_I^T dR_W_I/dt`).
- `accel`: ideal specific force in the IMU frame, gravity included: `f_I = R_W_I^T (a_W - g_W)`. At rest it reads
  9.81 m/s^2 pointing up.
- **Ideal** means noise-free, bias-free, unit scale and no time offset.
- **One trajectory:** the twin samples one smooth trajectory, a cubic B-spline on SE(3) (the space of full poses,
  rotation and translation) with 5 ms knots, fitted to the motion's design poses. Every column, the poses
  included, comes from it analytically, so the columns agree with each other.
- **Between samples:** interpolate the pose (slerp + linear, or your own spline). The finite-difference check in
  `check_pack.py` shows how close that is.
- The camera pose at time t is `T_W_C(t) = T_W_I(t) T_I_C`.

### `motions/<id>_camera_times.csv`

- **Camera:** the trigger stamps (camera clock) the twin used. They are evenly spaced at the rig's camera rate
  (20 Hz), from 0.4 s to 0.4 s before the end.
- **IMU:** the twin's IMU stream runs at 400 Hz, from 0.3 s to 0.3 s before the end.

## The rigs (`rigs/<rig>.yaml`)

Both rigs are a twin of our Looper Insight 9:

- **Camera:** its left camera, 544 x 640 px, kb4 fisheye (the Kannala–Brandt lens model with 4 distortion
  terms), 20 Hz, global shutter, 2 ms exposure.
- **IMU:** its 400 Hz IMU.
- **T_I_C:** from a real calibration.

They differ only in the board:

- **AprilGrid** (`G3_insight9_aprilgrid`): 6 x 6 tag36h11 tags of 43.47 mm, spacing ratio 0.3 (gap 13.04 mm),
  144 corners. A partial board is fine: every corner in the image counts.
- **Chessboard** (`G3_insight9_chess`): 10 x 7 squares of 43.47 mm = 9 x 6 inner corners, 54 points. Whole board
  only, as for a real chessboard detector. A frame gives corners only if all of these are in the image:
  - every inner corner;
  - the outer outline: the 4 outer corners and 4 edge midpoints, one square beyond the inner grid.

Each YAML holds:

- the camera model and its projection formula, the intrinsics and the image size;
- `T_I_C` as a rotation vector, a quaternion, a translation and a 4 x 4 matrix;
- the truth for `td` (3 ms) and `t_ga` (1.5 ms; the time offset between the gyroscope and accelerometer channels);
- the IMU intrinsics truth;
- the noise, the gates and the solve setup.

The truth values are the twin's injected values, not the real Insight 9's. Replay with them to reproduce our
numbers.

## How to replay it in any simulator

For each motion, with its rig:

1. **Trajectory.** Read `motions/<id>.csv` and build a continuous `T_W_I(t)` (interpolate or fit a spline).
2. **Camera.** For each stamp `t_cam` in `<id>_camera_times.csv`:
   - take the pose at IMU time `t_cam + td` (`td` = 3 ms), `T_W_C = T_W_I T_I_C`;
   - project the board points (`rigs/<rig>_board_points.csv`, world = board) with the kb4 model;
   - keep a point if its depth is 0.05–15 m and it lands inside the image.

   Then:
   - chessboard: drop the whole frame unless the full board and its outline are in the image;
   - drop corners seen at more than 75 deg from the board normal;
   - drop corners whose noise-free image speed times the 2 ms exposure exceeds 1.5 px (motion blur);
   - add 0.5 px Gaussian noise to u and v, and drop each remaining corner with probability 0.05.
3. **IMU.** At 400 Hz from 0.3 s to the end minus 0.3 s:
   - take the ideal gyro `w` at the stamp `t` and the ideal specific force `f` at `t - t_ga`
     (`t_ga` = 1.5 ms: the accelerometer lags the gyro);
   - apply the IMU model of the YAML, `w_m = inv(Dw) w + Tg f + b_g` and `a_m = inv(Da) f + b_a`, with the given
     Dw, Da and Tg;
   - add white noise (density / sqrt(dt) per sample);
   - let the biases walk (walk density x sqrt(dt) per sample) from an initial bias drawn with sigma 0.005 rad/s
     (gyro) and 0.05 m/s^2 (accel).
4. **Seeds.** Do this for 3 noise seeds, plus one noise-free run. The noise-free run has no IMU noise, zero
   biases, 1e-4 px corner noise and no dropout; the incidence and blur gates stay.
5. **Calibrate** each run with your tool:
   - estimate T_I_C, td and t_ga;
   - keep the camera intrinsics free;
   - estimate IMU scale (and misalignment if your model has it).

   Our setup is in `solve_setup`.
6. **Compare with the truth** and apply the pass rule below. `results/<id>.json` has our numbers for each step;
   `results/reference_sigmas.json` has the reference sigmas.

Your sigmas will differ from ours if your estimator or IMU model differs. When you can, compare a motion with a
reference that you have also run through your own tool.

## The pass rule

**22 parameters are judged:**

- the camera–IMU rotation error as a log(R) rotation vector (x, y, z in camera axes, mrad);
- the lever arm (the camera–IMU position offset; x, y, z in camera axes, mm);
- td and t_ga (ms);
- gyro and accelerometer scale (x, y, z, ppm);
- the camera intrinsics fx, fy, cx, cy (px) and k1..k4.

**How errors and sigmas are taken:**

- **Errors:** the T_I_C error is `Log(T_I_C_true^-1 T_I_C_est)`. Every other error is estimate minus truth.
- **sigma:** the solver's formal 1-sigma (its own uncertainty estimate), taken as the median over the 3 noise
  seeds.
- **Reference:** an 80 s well-excited motion on the same rig. AprilGrid motions are judged against the AprilGrid
  reference, chessboard motions against the chessboard one. `sigma_ref` is its sigma.

A motion passes a parameter if all four hold:

1. **Every solve converged.**
   - All 3 noise seeds and the noise-free run finished, with finite errors and positive sigmas.
   - Each noisy reprojection RMS is at most 1.5 x the reference's median noisy reprojection RMS.
   - The noise-free reprojection RMS is below 0.05 px.
2. **The noise-free run finds the truth.** Its |error| is at most max(sigma_ref, floor). Floors:
   - rotation and lever 0.01 (mrad, mm);
   - td 0.001 ms, t_ga 0.002 ms;
   - scales 10 ppm;
   - fx fy cx cy 0.01 px, k1..k4 1e-5.
3. **Errors match the sigmas.** |error| / sigma (each seed with its own sigma) is above 3 on fewer than 2 of
   the 3 seeds, and above 4 on none.
4. **Excited enough.** sigma is at most 3 x sigma_ref, compared raw (no scaling for a shorter motion).

A motion is **good** if every parameter passes. All four motions in this pack pass.

## `results/<id>.json`

- **Per motion:** `passed`, `failed_params`, `n_frames`, and `reproj_px` per solve (`s0`, `s1`, `s2`, `nf`).
- **Per parameter:**
  - `sigma` (median over seeds), `sigma_ref`, `sigma_ratio` = sigma / sigma_ref;
  - `err_seeds`, `z_seeds` (|err| / sigma per seed);
  - `noise_free_err`, `noise_free_limit`;
  - `passed` and `failed` (reasons, empty when it passes).

## Check script

Run `python3 check_pack.py` (numpy only). It:

- checks that the quaternions are unit length;
- recomputes the gyro from the quaternions and the specific force from the positions, by finite differences;
- prints the RMS difference to the gyro and accel columns.

The difference is the finite-difference error at 200 Hz. It is larger for the faster real takes.
